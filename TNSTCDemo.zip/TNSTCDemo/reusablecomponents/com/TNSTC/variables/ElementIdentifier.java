package com.TNSTC.variables;

public class ElementIdentifier {
	

	

	
	protected static String username="USER";
	protected static String passwd="PASSWORD";
	protected static String login="login_button";
	
	
	

}
