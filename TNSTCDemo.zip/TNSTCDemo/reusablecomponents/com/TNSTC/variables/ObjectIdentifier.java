package com.TNSTC.variables;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ObjectIdentifier extends ElementIdentifier{

	
	protected static WebDriver driver;
	protected static DriverMethods drivermethod=new DriverMethods();
	
	protected static WebDriverWait wait;
	
	
	
	
}
