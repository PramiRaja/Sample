package com.TNSTC.variables;

import org.openqa.selenium.By;

public class DriverMethods extends ObjectIdentifier {
	
	
	public  void launch()
	{
		driver.get("https://www.ultimatix.net");
		driver.manage().window().maximize();
		
	}
	
	public  void ClickbyxPath(String xpath)
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	
	public  void entertextbyname(String name,String text)
	{
		driver.findElement(By.name(name)).sendKeys(text);
	}
	
	public  void Clickbyclassname(String classname)
	{
		driver.findElement(By.className(classname)).click();
	}
	
	public  void entertextbyxPath(String xpath,String text)
	{
		driver.findElement(By.xpath(xpath)).sendKeys(text);
	}

	public void entertextbyid(String id,String text)
	{
		driver.findElement(By.id(id)).sendKeys(text);
		
	}
	
	public void clickbyid(String id)
	{
		driver.findElement(By.id(id)).click();
	}
}

