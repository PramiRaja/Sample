package com.TNSTC.testcases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.TNSTC.variables.ObjectIdentifier;

public class ApplicationLaunch extends ObjectIdentifier {

	
	@BeforeTest

	public  void before()
	{
		System.out.println("Test Started");
		System.setProperty("webdriver.chrome.driver", "..//TNSTCDemo/Library/chromedriver.exe");
		driver=new ChromeDriver();
		drivermethod.launch();
		
	}
	
	
	@Test
	
	public void login() throws InterruptedException
	{
		Thread.sleep(2000);
	
		Thread.sleep(10000);
		drivermethod.entertextbyid(username, "Bindhu");
		drivermethod.entertextbyid(passwd, "01Dec@2016");
		drivermethod.clickbyid(login);
		
		System.out.println("Test Executed Successfully");
		
		
	}
		
	@AfterTest
	
	public void after()
	{
		
		System.out.println("Test Ends");
		//driver.close();
		driver.quit();
		
	}

}
